package codegym.vn.repository;

import codegym.vn.entity.Category;

public interface CategoryRepository extends Repository<Category> {
}
